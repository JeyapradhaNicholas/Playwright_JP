/*let num=10
if (num>0){
    console.log("NUmber is +ve:" +num)
}
else{
    console.log("Number is -ve:" +num)
}*/

let num=-8
if(num>0){
    console.log("Number is +ve:"+num)
}
elseif(num==0)
    
