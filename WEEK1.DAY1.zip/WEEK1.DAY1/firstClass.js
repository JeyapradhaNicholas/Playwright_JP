console.log("Welcome to Playwright")
console.log("I am an automation expert")
console.log("Hi Jeyapradha")
console.log(123456)
console.log("#$@$%^&*&^$%#&*")
console.log(null)
n="jeyapradha"
console.log(n)


/*console.log("hi")
d=78
console.log(d)
console.log(typeof(d))*/