/*var a=10
console.log(a)//output will be 10

//hoisting

var x
console.log(x)  //undefined
x=20
console.log(x) //output=20

//another realtime example

var pizza
console.log(pizza)
var pizza="veg pizza"
console.log(pizza)*/

console.log(pi)
const pi=3.14
 console.log(pi)
