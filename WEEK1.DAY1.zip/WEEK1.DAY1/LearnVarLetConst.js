var dosa="1"
var dosa="2"
console.log(dosa)

let dosa=1
dosa=2
console.log(dosa)
